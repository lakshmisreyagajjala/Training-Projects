package com.lumen.training;

import com.lumen.exceptions.NegativeValueException;

public class Student {

	public int totalMarks(int markOne, int mark2, int mark3) throws NegativeValueException{
		

			if(markOne < 0 | mark2 < 0 | mark3 < 0) {
				throw new NegativeValueException("Marks shouldn't be negative values");
			}
			return markOne + mark2 + mark3;
			
	}
	public String getGrades(int... marks) throws NegativeValueException {
		
		for (int mark : marks) {
			if(mark<0) {
				throw new NegativeValueException("Marks are negative");
			}
		}
		
		if(marks.length==0) {
			return "0";
			}
		int sum = 0;
		for (int mark : marks) {
			sum+=mark;

        }

        int avg = sum/marks.length;

        String grade="";

        

        if(avg>90 && avg<100) {

            grade = "A";

        } else if (avg>80 && avg<90) {

            grade="B";

        } else if(avg>70 && avg<80) {

            grade="C";

        } else if(avg>60 && avg<70) {

            grade ="D";

        } else {

            grade="fail";

        }
        return grade;
	}
		
			
}


