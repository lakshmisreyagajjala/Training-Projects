package com.lumen.exceptions;

public class NegativeValueException extends RuntimeException{

	public NegativeValueException() {
		super();
	}

	public NegativeValueException(String message) {
		super(message);
	}
	
	

}
