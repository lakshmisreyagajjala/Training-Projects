package com.lumen.training;

public class Calculator {

	public double sum(double x, double y) {

		return x+y;

	}

	public int product(int x, int y) {

		return x*y;

	}

}
