package com.suites;

import org.junit.platform.suite.api.ExcludePackages;
import org.junit.platform.suite.api.IncludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
//selects all the classes in this package and the classes in the sub packages
@SelectPackages({"com.lumen"})
//excludes all the classes in this package only
//@ExcludePackages({"com.lumen.testcases"})
//includes all the classes in this package only
@IncludePackages({"com.lumen.testcases.trial"})

public class AllTests {
	

}

