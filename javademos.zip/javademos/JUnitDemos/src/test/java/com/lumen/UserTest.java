package com.lumen;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.lumen.training.User;

public class UserTest {
	
		User user;
	
		@BeforeAll
		static void setUpBeforeClass() throws Exception {
			System.out.println("before all");
			
			}
	
		@AfterAll
		static void tearDownAfterClass() throws Exception {
			System.out.println("After all");
	
		}
	
		@BeforeEach
		void setUp() throws Exception {
			System.out.println("before each");
			user = new User();
	
		}
	
		@AfterEach
		void tearDown() throws Exception {
			System.out.println("after each");
			user = null;
	
		}
	
		@Test
		@Tag("greet")
		@DisplayName("User Greet testing")
		void greetTest() {
			assertEquals("Hello nikki", user.greet("nikki"));
	
		}
	
		@Test
		@Tag("first")
		@DisplayName("User fruit testing")
		void testFruits() {
			List<String> fruits = Arrays.asList("mango", "apple");
			assertEquals(fruits, user.showFruits());
	
		}
	
		@Test
		@DisplayName("User product testing")
		void testProduct1() {
			assertEquals(40, user.product(5, 8));
	
		}
		
		@Test @DisplayName("User product testing")
		void testProduct() {
			assertEquals(40, user.product(5, 8));

	    }

	    

	    @Test @DisplayName("Testing fruit length")
	    void testFruitLength() {
	    	List<String> fruits = Arrays.asList("mango","apple");
	    	assertEquals(2, fruits.size());

	    }

	 

}
