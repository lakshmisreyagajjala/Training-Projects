package com.lumen.testcases.trial;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.lumen.exceptions.NegativeValueException;
import com.lumen.training.Student;

class StudentTest {
	
	Student student;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before All");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("After All");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("Before Each");
		student = new Student();
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("After Each");
		student = null;
	}

	@Test@DisplayName("Testing totalMarks - positive")
	void test() {
		assertEquals(90,student.totalMarks(30,30,30));
	}
	
	@Test @DisplayName("Testing negative value")
	void testNegTotal() {
		assertThrows(NegativeValueException.class,()->student.totalMarks(-90,90,80));
	}
	
	@Test @DisplayName("Grade testing")

    void testGrade() {

        assertEquals("A", student.getGrades(92,94,93));

    }

    @Test @DisplayName("Grade negative testing")

    void validGrade() {

        assertThrows(NegativeValueException.class, ()->student.getGrades(-90,90,10));

    }

 
	

	

}

