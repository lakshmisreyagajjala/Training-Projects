package com.lumen.objbasics;

public class StudentMain {

	public static void main(String[] args) {
		
			
			Student student=new Student("viswa","cse");
            
			student.printDetails();
	       
  		
			student.getGrades(92,56,71);
			
	
			Student student1 = new Student("vinay", "eee");
			
			student1.printDetails();
			
			student1.getGrades(81,91,87);

}
}
