package com.lumen.fun;

public interface Shape {
	
	void CalcArea(double x, double y);

}
