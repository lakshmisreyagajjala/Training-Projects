package com.lumen.basics;

import java.util.Arrays;

public class SecondSmall {

	public static void main(String[] args) {
		
		int [] array=new int[] {2,25,11,34,54,59};
	      Arrays.sort(array);
	      int Smallest=array[1];
	      System.out.println("SecondSmallest number:"+Smallest);

	}

}
