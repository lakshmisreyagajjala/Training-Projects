package com.lumen.lang;

public class Main {

	public static void main(String[] args) {
		
		Employee employee = new Employee("Vish",502,30000);
		System.out.println(employee);

		int x=10;
		long y=x; //upcasting
		Long a=y; //autoboxing
		
		int b=(int)y; //downcasting
		//convert to object
		Object o=a; //this is of type long
		
		//trying to downcast will through classcastexception
		Integer i =(Integer)o; //exception
	}

}
