package com.lumen.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkDemo {

	public static void main(String[] args) {

		LinkedList<String> list = new LinkedList<>();
		list.add("Java");
		list.add("100");
		list.add("100.9");
		list.add("Spring");
		list.add("angular");
		list.add("maven");
		list.add(1, "Helen");
		System.out.println(list);
		list.addFirst("Html");
		list.addLast("Css");
		list.set(2, "sree");
		System.out.println(list.size());
		System.out.println(list.get(0));

		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			String name = iterator.next();
			System.out.println(name.toLowerCase());
		}

		Collections.sort(list);
		System.out.println(list);

		for (String name : list) {
			System.out.println(name.toUpperCase());
			System.out.println(list.size());
			list.set(1, "Lucky");
			list.set(2, "Chinni");
			System.out.println(list.get(2));

			System.out.println("Reverse");
			ListIterator<String> listIterator = list.listIterator(list.size());
			while (listIterator.hasPrevious()) {
				String name1 = listIterator.previous();
				System.out.println(name1.toUpperCase());
			
				
			System.out.println("Methods");
			System.out.println(list.peek());
			System.out.println(list);
			System.out.println(list.poll());
			System.out.println(list);
			System.out.println(list.poll());
			System.out.println(list);
			System.out.println(list.poll());
			System.out.println(list);
			System.out.println(list.remove());
				
				
			}

		}

	}
}
