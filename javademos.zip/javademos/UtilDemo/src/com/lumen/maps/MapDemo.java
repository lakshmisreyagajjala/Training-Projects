package com.lumen.maps;

import java.security.KeyStore.Entry;
import java.util.HashMap;
//import java.util.Map;
import java.util.Set;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {
		
		Map<Integer,String> hashMap = new HashMap<>();
		hashMap.put(8, "Node");
		hashMap.put(10, "Java");
		hashMap.put(7, "Spring");
		hashMap.put(null, "Css");
		hashMap.put(3, "Angular");
		hashMap.put(5, "Html");
		hashMap.put(1, "React");
		hashMap.put(20, "null");
		hashMap.put(40, "null");
		System.out.println(hashMap);
		System.out.println(hashMap.get(3));
		System.out.println(hashMap.get(40));
		System.out.println(hashMap.getOrDefault(30,"Node"));
		System.out.println(hashMap.containsKey(3));
		
		Set<Integer> keys = hashMap.keySet();
		for(Integer key:keys) {
			System.out.println(key+" "+hashMap.get(key));
		}
		System.out.println();
		
//		Set<Entry<Integer,String>> map = hashMap.entrySet();
		for(java.util.Map.Entry<Integer, String> entry : hashMap.entrySet()) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		System.out.println();
		
		for(Map.Entry<Integer,String> entry : hashMap.entrySet()) {
			Integer key = entry.getKey();
			String val = entry.getValue();
			System.out.println(key+" "+val);
		}
			
		

	}

}
