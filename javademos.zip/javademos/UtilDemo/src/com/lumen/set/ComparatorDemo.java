package com.lumen.set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorDemo {

	public static void main(String[] args) {
		
		Vehicle vehicle1 = new Vehicle("Honda","Hero",35000);
		Vehicle vehicle2 = new Vehicle("Suzuki","Motors",75000);
		Vehicle vehicle3 = new Vehicle("Bajaj","Bandi",30000);
		Vehicle vehicle4 = new Vehicle("Vespa","Scooty",100000);
		
		List<Vehicle> vehicles = new ArrayList<>();
		
		vehicles.add(vehicle1);
		vehicles.add(vehicle2);
		vehicles.add(vehicle3);
		vehicles.add(vehicle4);
		
		System.out.println("List of Vehicles");
		Comparator<Vehicle> comparator = new BrandSort();
		Collections.sort(vehicles,comparator);
		for(Vehicle vehicle : vehicles) {
			System.out.println(vehicle);
		}
		System.out.println("Sorting using brand");
		Comparator<Vehicle> comparator1 = new ModelSort();
		Collections.sort(vehicles,comparator1);
		for(Vehicle vehicle : vehicles) {
			System.out.println(vehicle);
		}
		System.out.println("Sorting using Lambda");
		Comparator<Vehicle> comparator2 = new PriceSort();
		Collections.sort(vehicles,comparator2);
		for(Vehicle vehicle : vehicles) {
			System.out.println(vehicle);
		}
		
		
	}

}

