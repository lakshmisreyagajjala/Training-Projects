package com.lumen.set;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparatorLambda {

	public static void main(String[] args) {
		
		List<Vehicle> vehicles = Arrays.asList(new Vehicle("City","Honda",300000),
				new Vehicle("Hexa","Tata",40000),new Vehicle("Santro","Hyundai",50000),
				new Vehicle("A100","Audi",700000));
		
		for(Vehicle vehicle : vehicles) {
			System.out.println(vehicle);
		}
		
		Collections.sort(vehicles,(Vehicle o1, Vehicle o2)->{
			return o1.getBrand().compareTo(o2.getBrand());
		});
		
		System.out.println("By brand");
		for(Vehicle nvehicle : vehicles) {
			
		}


	}

}

