package com.lumen.set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	
	public static void main(String[] args) {
		
		Set<String> hashSet = new TreeSet<>();
		hashSet.add("Apple");
		hashSet.add("Mango");
		hashSet.add("Strawberry");
		hashSet.add("300");
		hashSet.add("Orange");
		System.out.println(hashSet);
		
		for(String element : hashSet) {
			System.out.println(element);
		}
		
	}

}

