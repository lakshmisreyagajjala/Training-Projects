package com.lumen.set;

import java.util.Arrays;
import java.util.NavigableSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class NaviSet {

	public static void main(String[] args) {
		
		NavigableSet<String> set = new TreeSet<>(Arrays.asList("apple","strawberry","mango","orange","kiwi"));
		System.out.println(set);
		System.out.println(set.descendingSet());
		
		SortedSet<String> headData = set.headSet("mango");
		System.out.println(headData);
		
		SortedSet<String> headData1 = set.headSet("mango",true);
		System.out.println(headData1);
		
		SortedSet<String> tailData = set.tailSet("mango");
		System.out.println(tailData);
		
		System.out.println(set.ceiling("kiw"));
		System.out.println(set.first());
		System.out.println(set.last());
		System.out.println(set.floor("mang"));
		System.out.println(set.floor("orange"));
		
		

	}

}
