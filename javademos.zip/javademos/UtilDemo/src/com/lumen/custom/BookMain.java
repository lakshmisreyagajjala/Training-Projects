package com.lumen.custom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class BookMain {

	public static void main(String[] args) {
		
		Book book1 = new Book("Bhavya","Sree",50);
		Book book2 = new Book("Vishuuu","Viswa",200);
		Book book3 = new Book("Kind-Hearted","Nikki",3000);
		
		List<Book> books = new ArrayList<>();
		books.add(book1);
		books.add(book2);
		books.add(book3);
		
		Scanner scanner = new Scanner(System.in);
		String authorname = scanner.next();
		
	    List<Book> booksByAuthor = new ArrayList<>();
	    
		for(Book book:books) {
	    	System.out.println(book);
	    
		if(book.getAuthor().equals("Nikki")) {
			booksByAuthor.add(book);
		}
		}
		
		Collections.sort(books);
		
		System.out.println(booksByAuthor);
		
//		Iterator<Book> iterator = books.iterator();
//		while(iterator.hasNext()) {
//			Book booklist = iterator.next();
//			System.out.println(booklist);
//		}
		

	}
	

}
