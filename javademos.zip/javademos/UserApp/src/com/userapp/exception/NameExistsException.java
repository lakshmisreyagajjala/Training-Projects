package com.userapp.exception;

public class NameExistsException extends Exception {

	public NameExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NameExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
