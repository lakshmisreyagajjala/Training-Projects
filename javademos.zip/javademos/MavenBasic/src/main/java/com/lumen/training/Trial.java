package com.lumen.training;

public class Trial {

	public static void main(String[] args) {

	}

}
