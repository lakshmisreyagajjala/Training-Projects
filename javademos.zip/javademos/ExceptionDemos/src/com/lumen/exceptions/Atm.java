package com.lumen.exceptions;

public class Atm  {
	
	public static void main(String[] args) {
		
		System.out.println("In Atm");
		Bank bank = new Bank(3000);
		try {
		bank.withdraw(3000);
		System.out.println("Amount withdraw");
		}
		catch(Exception e) {
			System.out.println("Try again");
			System.out.println(e.getMessage());
		}
		
	}
	
	

}
