package com.lumen.custom;

public class CustomMain {

	public static void main(String[] args) {
		
		CustomBank custom = new CustomBank(300);
		try {
			custom.withdraw(300);
			System.out.println("amount details");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
