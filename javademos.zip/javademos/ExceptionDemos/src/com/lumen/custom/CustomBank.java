package com.lumen.custom;

public class CustomBank {

	double balance;
    
	 
	public CustomBank(double balance) {
		super();
		this.balance = balance;
	}


	void withdraw(double amount) throws ExceedingLimitException,NegativeBalanceException{
		System.out.println("Metho");
		if(amount>3000) {
			throw new ExceedingLimitException("Limit exceeded");
		}
		
		if(balance-amount<=0)
			throw new NegativeBalanceException("balance is negative");
		balance=balance-amount;
		System.out.println("Balance "+balance);
	 

    }
	
	
}