package com.lumen.custom;

public class ExceedingLimitException extends Exception{

	public ExceedingLimitException() {
		super();
	}

	public ExceedingLimitException(String message) {
		super(message);
	}
	
	

}
