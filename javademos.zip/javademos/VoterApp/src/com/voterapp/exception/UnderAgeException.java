package com.voterapp.exception;

public class UnderAgeException extends Exception{

	public UnderAgeException() {
		super();
	}

	public UnderAgeException(String message) {
		super(message);
	}
	
	

}
