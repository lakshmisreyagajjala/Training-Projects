package com.voterapp.exception;

public class NotVoterIDException extends Exception{

	public NotVoterIDException() {
		super();
	}

	public NotVoterIDException(String message) {
		super(message);
	}
	
	

}
