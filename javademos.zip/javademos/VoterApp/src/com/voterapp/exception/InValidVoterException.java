package com.voterapp.exception;

public class InValidVoterException extends Exception {

	public InValidVoterException() {
		super();
	}

	public InValidVoterException(String message) {
		super(message);
	}

	
	
	

}
