package com.voterapp.exception;

public class LocalityNotFoundException extends Exception{

	public LocalityNotFoundException() {
		super();
	}

	public LocalityNotFoundException(String message) {
		super(message);
	}
	
	
	

}
