package com.lumen.io;

import java.io.FileReader;
import java.io.FileWriter;

public class TryWithResources {

	public static void main(String[] args) {

		try(
				FileWriter writer = new FileWriter("trail.txt");
				FileReader reader = new FileReader("demo.txt");
				){
			
			int num = reader.read();
			writer.write((char)num);
			do {
				num = reader.read();
				writer.write((char)num);
			}while(num!=-1);
		}catch(Exception e) {
			e.printStackTrace();
		}
				
				
	}

}
