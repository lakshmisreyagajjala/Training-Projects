package com.lumen.io.serial;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SerialDemo {

	public static void main(String[] args) {

		Student student = new Student();
		student.setStudentName("bhavi");
		student.setStudentId(531);
		student.setDepartment("CSE");
		
		try(FileOutputStream outputStream = new FileOutputStream("stud.ser");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);){
			objectOutputStream.writeObject(student);
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
