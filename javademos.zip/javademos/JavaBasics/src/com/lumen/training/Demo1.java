package com.lumen.training;

public class Demo1 {

	public static void main(String[] args) {
		System.out.print("Hello\t");
		int x=90;
		int y=90;
		System.out.print("Sum"+(x+y)+"\n");
		System.out.println("\'Welcome to Java\'");
		
//		float num=32.5f;
//		upcasting
		byte a=10;
		int b=a*2;
		long num=a+b;
		System.out.println(num);
		
		int num1=(int)num;
		float amount=num1*num1;
		double result=amount+10;
		
		float data=(float)result;
		int c=(int)data;
		System.out.println(data);
		System.out.println(c);
		
		byte b1=10;
		byte b2=20;
		byte b3=(byte)(b1+b2);
		int b4=b1+b2;
		
		int x1=100;
		int x2=200;
		byte x3=(byte)x1+x2;
		
		
		
		

	}

}
