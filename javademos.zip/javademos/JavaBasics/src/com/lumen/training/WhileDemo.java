package com.lumen.training;

public class WhileDemo {

	public static void main(String[] args) {
//		int a=3;
//		while (a<10) {
//			System.out.println(a);
//			a++;
//			
//		}
//
//	}

		int b=1;
		do {
			System.out.println(b);
			b++;
		} while (b<10);

}
}
