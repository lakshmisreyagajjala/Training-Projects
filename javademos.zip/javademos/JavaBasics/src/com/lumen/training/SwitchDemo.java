package com.lumen.training;

public class SwitchDemo {

	public static void main(String[] args) {
//		int a=10;
//		int b=20;
//		
//		switch(a+b){
//		case 30:{
//			System.out.println("welcome");
//			break;
//		}
//		case 40:{
//			System.out.println("Hello");
//		}
//	    default:{
//	    	System.out.println("Great");
//	    }
//		}
//
//	}
     String choice="Monday";
		switch(choice) {
		case "Monday":{
			System.out.println("Weekday");
			break;
		}
		case "Tuesday":{
			System.out.println("Weekday");
			break;
		}
		case "Wednesday":{
			System.out.println("Weekday");
			break;
		}
		case "Thursday":{
			System.out.println("Weekday");
			break;
		}
		case "Friday":{
			System.out.println("Weekday");
			break;
		}
		case "Saturday":{
			System.out.println("Weekend");
			break;
		}
		case "Sunday":{
			System.out.println("Restday");
			break;
		}
		
    }
}
}		
