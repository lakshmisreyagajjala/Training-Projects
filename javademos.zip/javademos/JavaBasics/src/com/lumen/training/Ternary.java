package com.lumen.training;

public class Ternary {
	public static void main(String args[]) {
//		int x=101;
//		String result=x>100?"Hello":"welcome";
//		System.out.println(result);
		
		int a=50;
		int b=40;
		int c=30;
		String result=a>b&&a>c?"a":b>c&&b>a?"c":"b";
		System.out.println(result);
		
	}

}
