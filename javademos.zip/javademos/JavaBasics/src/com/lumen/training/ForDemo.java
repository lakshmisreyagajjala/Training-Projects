package com.lumen.training;

public class ForDemo {

	public static void main(String[] args) {
        int a=10;
        int b=20;
        
        for(int i=0;i<10;i++) {
        	System.out.println(i*5);
        }
	}

}
