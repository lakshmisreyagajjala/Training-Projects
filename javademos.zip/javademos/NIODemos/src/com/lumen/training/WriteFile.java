package com.lumen.training;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class WriteFile {

	public static void main(String[] args) {

		// create file for reading
		RandomAccessFile randomFile;
		
		try {
			
			randomFile = new RandomAccessFile("demo2.txt", "rw");
            // get the channel from the file
			FileChannel channel = randomFile.getChannel();
            // create the buffer with the size for reading
			ByteBuffer buffer = ByteBuffer.allocate(100);
            // read from channel and write into buffer
			int bytesRead = channel.read(buffer);
			System.out.println(bytesRead);
			buffer.put("my name is lucky".getBytes());
			// flip the buffer --convert read to write vice versa
			buffer.flip();
			channel.write(buffer);
			buffer.flip();
			while (buffer.hasRemaining()) {
				char c = (char) buffer.get();
				System.out.print(c);

			}

		} catch (IOException e) {
			e.printStackTrace();

		}

	}

}
