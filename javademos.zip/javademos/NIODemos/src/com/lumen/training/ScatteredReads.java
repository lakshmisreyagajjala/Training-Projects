package com.lumen.training;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class ScatteredReads {
	
	public static void main(String[] args) {
		
		RandomAccessFile randomFile;

        try {
        	randomFile = new RandomAccessFile("demo3.txt", "rw");
        	FileChannel channel = randomFile.getChannel();
        	ByteBuffer buffer1 = ByteBuffer.allocate(2);
        	ByteBuffer buffer2 = ByteBuffer.allocate(100);
        	ByteBuffer[] byteArray = {buffer1,buffer2};
        	channel.read(byteArray);
        	System.out.println();
        	buffer1.flip();
        	buffer2.flip();
        	
        	while(buffer1.hasRemaining()) {
        		System.out.print((char) buffer1.get());

            }
        	System.out.println();

            while(buffer2.hasRemaining()) {
            	System.out.print((char) buffer2.get());

            }

        } catch (IOException e) {
        	e.printStackTrace();

        }


    }
 

}

 
