package com.lumen.training;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class GatheredWrites {

	public static void main(String[] args) {
		
		RandomAccessFile randomFile;

        try {
        	randomFile = new RandomAccessFile("demo4.txt", "rw");
        	FileChannel channel = randomFile.getChannel();
        	
        	ByteBuffer buffer1 = ByteBuffer.allocate(20);
        	ByteBuffer buffer2 = ByteBuffer.allocate(100);
        	
        	buffer1.put("First Data is out".getBytes());
        	buffer2.put("Second Data still waiting".getBytes());
        	
        	ByteBuffer[] byteArray = {buffer1,buffer2};
        	System.out.println();
        	buffer1.flip();
        	buffer2.flip();
        	
        	channel.write(byteArray);
        	System.out.println();

         } catch (IOException e) {
        	 e.printStackTrace();

        }

	}

}

