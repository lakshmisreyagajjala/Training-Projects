package com.lumen.inter2;

public interface BasicCalculator {
	
	void add(int x, int y);
	void difference(int x, int y);
	void product(int x, int y);
	void divide(int x, int y);
	 
    

}

