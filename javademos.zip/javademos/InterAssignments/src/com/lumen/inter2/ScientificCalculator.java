package com.lumen.inter2;

public interface ScientificCalculator extends BasicCalculator {
	

	void square(int x);
	void cube(int x);
     
}


