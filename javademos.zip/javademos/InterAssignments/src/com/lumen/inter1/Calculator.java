package com.lumen.inter1;

public interface Calculator {
	
	void calculate(int x, int y);

}
