package com.lumen.streams;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class InStreamsDemo {
	
	public static void main(String[] args) {
		
		List<String> courses = Arrays.asList("Java","Angular","Node","JS","Spring","CSS");
		//convert to stream
		Iterator<String> iterator = courses.stream()
		                            .filter(str->str.length()>3)
		                            .skip(4)
		                            .iterator();  //terminal
		
		while(iterator.hasNext()) {
			String cname = iterator.next();
			System.out.println(cname);
		}
		System.out.println();
		courses.stream()
		       .filter(str->str.length()>3)
		       .distinct()
		       .limit(2)
		       .forEach(str->System.out.println(str.toUpperCase()));
		
		System.out.println();
		List<Integer> ncourses = courses.stream()
		                                .sorted()
		                                .map(str->str.length())
		                                .filter(num->num>4)
		                                .collect(Collectors.toList());  //convert into a list
		ncourses.forEach(num->System.out.println(num));
		
		//convert the list to stream and use map to get length and
		//use filter to check if it is divisible by 2
		//print only that values using for each
		System.out.println();
		List<Integer> ncourses1 = courses.stream()
				                         .sorted()
                                         .map(str->str.length())
                                         .filter(num->num%2==0)
                                         .collect(Collectors.toList());
		ncourses1.forEach(num->System.out.println(num));
		
		
		
	}

}

