package com.lumen.streams;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class CreateStream {

	public static void main(String[] args) {
		
		String[] names = new String[] {"Bhavi","Nikki","Lucky","Vishuu","Karthi"};
		//create a stream from an array
		Stream.of(names).forEach(name->System.out.println(name));
		
		Arrays.stream(names).forEach(name->System.out.println(name));
		
		int[] nums = {10,28,35,58,31,46};
		int sum = Arrays.stream(nums,2,4)
				        .filter(num->num%2==0)
				        .sum();
		System.out.println(sum);
		
		IntStream stream = Arrays.stream(nums,2,5);
		   double sum1=stream.mapToObj(num->String.valueOf(num)) //convert primitive to
				.mapToDouble(str->Double.parseDouble(str))
				.sum();
		System.out.println(sum1);
		
		Arrays.stream(nums,1,5)
		   .map(num->(int)Math.pow(num, 2)) //convert primitive to
		   .forEach(n->System.out.println(n));
		
		//create an infinite stream
		Stream.generate(()->"Hello").limit(3).forEach(System.out::println);
		

	}

}


































