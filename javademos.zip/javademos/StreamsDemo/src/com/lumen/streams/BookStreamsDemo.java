package com.lumen.streams;

import java.util.Arrays;

import java.util.List;
import java.util.stream.Collectors;

public class BookStreamsDemo {

	public static void main(String[] args) {
		
		//create a list of Books-> convert to stream-> get books by author->print
		List<Book> books = Arrays.asList(new Book("Java","Priya",3000),
				      new Book("Spring","Sree",1000),
				      new Book("Angular","Nikki",2000)
				);
		books.stream()
		    .filter(book->book.getAuthor().equals("Nikki"))
		    .map(book->book.getTitle())
		    .forEach(book->System.out.println(book));
		
		//create a list of Books->convert to stream
		//get only the title -> get the length of each title
		//square it and convert to list
		List<Double> book1 = books.stream()
				.map(book2 -> book2.getTitle())
				.map(titleLen -> Math.pow(titleLen.length(), 2))
				.collect(Collectors.toList());
		
		book1.forEach(pow -> System.out.println(pow));
				
		  

	}

}
