package com.lumen.streams;

import java.util.Arrays;
import java.util.stream.Stream;

public class FlatDemo {

	public static void main(String[] args) {
		
		String[] names = new String[] {"Khajipet","Kadapa","proddatur","Mydukur"};
		Arrays.stream(names).forEach(name->System.out.println(name));
		String[][] items = new String[][] {{"box","book"},{"pen","pencil"},{"paper","bag"}};
		Arrays.stream(items).forEach(item->Arrays.stream(item).forEach(product->System.out.println(product)));
		
		String[][] courses = new String[][] {{"java","core"},{"node","js"},{"angular","react"}};
		Stream<String[]> streamTwo = Arrays.stream(courses);
		
		
		Arrays.stream(courses)
		      .flatMap(oneArr->Arrays.stream(oneArr))
		      .map(String::toUpperCase)
		      .forEach(System.out::println);
		
		

	}

}
