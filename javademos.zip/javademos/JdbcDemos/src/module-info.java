/**
 * 
 */
/**
 * 
 */
module JdbcDemos {
	
	requires java.sql;
}