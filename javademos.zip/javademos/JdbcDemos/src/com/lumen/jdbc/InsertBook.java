package com.lumen.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertBook {

	public static void main(String[] args) {
		

		String url="jdbc:mysql://localhost:3306/mysql";
		String username = "root";
		String password = "admin@123";
		
		String query = "insert into book values('Python','Nikki',1000)";
		String query1 = "insert into book values('Sql','Sreya',500)";
		String query2 = "insert into book values('Java','Karthik',1500)";
		String query3 = "insert into book values('spring','Viswa',500)";
        
		boolean result;
		try (Connection connection = DriverManager.getConnection(url,username,password);
			Statement statement = connection.createStatement()){
			result = statement.execute(query);
			System.out.println("Row inserted "+result);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
