package com.lumen.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDemo {

	public static void main(String[] args) {
		
		String url="jdbc:mysql://localhost:3306/mysql";
		String username = "root";
		String password = "admin@123";
		
		String query = "insert into employee values('Bhavya',531,'pdtr',45000)";
		String query1 = "insert into employee values('Sreya',535,'khjp',50000)";
		String query2 = "insert into employee values('Viswa',502,'pdtr',60000)";
		String query3 = "insert into employee values('Karthik',569,'pdtr',80000)";
        
		boolean result;
		try (Connection connection = DriverManager.getConnection(url,username,password);
			Statement statement = connection.createStatement()){
			result = statement.execute(query);
			System.out.println("Row inserted "+result);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}

