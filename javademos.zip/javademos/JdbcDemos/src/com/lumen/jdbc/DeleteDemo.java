package com.lumen.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteDemo {
	
	public static void main(String[] args) {
		
		String url="jdbc:mysql://localhost:3306/mysql";
		String username = "root";
		String password = "admin@123";
		
		String query = "update table employee set id=537 where name='Nikethan'";
        
		boolean result;
		try (Connection connection = DriverManager.getConnection(url,username,password);
			Statement statement = connection.createStatement()){
			result = statement.execute(query);
			System.out.println("Table created "+result);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
