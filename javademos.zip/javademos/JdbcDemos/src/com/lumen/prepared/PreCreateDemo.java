package com.lumen.prepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PreCreateDemo {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/mysql";
        String username = "root";
        String password = "admin@123";

        boolean result;
         try {

            Connection connection =  DriverManager.getConnection(url,username,password);

            String query =

                    "Create table movie(name varchar(20), movieId int primary key,city varchar(20), ticketPrice float)";


            PreparedStatement prepStatement = connection.prepareStatement(query);
            result = prepStatement.execute();
            System.out.println("Table created: "+result);

         
        } catch (SQLException e) {
            e.printStackTrace();

        }

        

 

    }

}


