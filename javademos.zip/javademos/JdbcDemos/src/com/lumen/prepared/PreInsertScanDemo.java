package com.lumen.prepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class PreInsertScanDemo {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/mysql";
        String username = "root";
        String password = "admin@123";

        boolean result;
        try {
            Connection connection =  DriverManager.getConnection(url,username,password);
            Scanner scanner = new Scanner(System.in);
            String name = scanner.next();
            int id = scanner.nextInt();
            String city = scanner.next();
            int ticket = scanner.nextInt();

            String query = 
                    "insert into movie values(?,?,?,?)";

            PreparedStatement prepStatement = connection.prepareStatement(query);
            prepStatement.setString(1, name);
            prepStatement.setInt(2, id);
            prepStatement.setString(3, city);
            prepStatement.setInt(4, ticket);

            result = prepStatement.execute();

            System.out.println("Table inserted: "+result);


        } catch (SQLException e) {
            e.printStackTrace();
        }


 

    }

}


