package com.lumen.prepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PreResultDemo {

	public static void main(String[] args) {

		String url = "jdbc:mysql://localhost:3306/mysql";
		String username = "root";
		String password = "admin@123";
		String sql = "select*from movie";
		
		  boolean result;
	        try {
	            Connection connection =  DriverManager.getConnection(url,username,password);
	            String query = 
	                    "select * from movie";

	            PreparedStatement prepStatement = connection.prepareStatement(query);
	            ResultSet result2 = prepStatement.executeQuery();

	            while(result2.next()) {
	                String name = result2.getString("name"); 
	                int id = result2.getInt("movieId");
	                String city = result2.getString("city");
	                int ticketPrice = result2.getInt("ticketPrice");
	                System.out.println(name+ " " + id + " " +city+ " "+ ticketPrice);
	            }


	        } catch (SQLException e) {
	            e.printStackTrace();
	        }


	    }

}
