package com.lumen.prepared;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

 

public class PreUpdateDemo {

 

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mysql";
        String username = "root";
        String password = "admin@123";

        boolean result;
        try {
            Connection connection =  DriverManager.getConnection(url,username,password);
            Scanner scanner = new Scanner(System.in);
            String name = scanner.next();
            int ticket = scanner.nextInt();

            String query = 
                    "update movie set ticketPrice=? where name=?";

            PreparedStatement prepStatement = connection.prepareStatement(query);
            prepStatement.setInt(1, ticket);
            prepStatement.setString(2, name);


            result = prepStatement.execute();

            System.out.println("Table updated: "+result);


        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}