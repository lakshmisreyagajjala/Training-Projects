package com.lumen.prepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieDemo {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/mysql";
		String username = "root";
		String password = "admin@123";
//		String sql = "select*from movie";
		
		  boolean result;
	        try {
	            Connection connection =  DriverManager.getConnection(url,username,password);
	            String query = 
	                    "select * from movie";

	            PreparedStatement prepStatement = connection.prepareStatement(query);
	            ResultSet result1 = prepStatement.executeQuery();
	            
	            List<Movie> movieList = new ArrayList();

	            while(result1.next()) {
	                String name = result1.getString("moviename"); 
	                int movieid = result1.getInt("movieid");
	                String city = result1.getString("city");
	                int ticketPrice = result1.getInt("price");
	                
	                Movie movie = new Movie(name,movieid,city,ticketPrice);
	                movieList.add(movie);
	            }
	            movieList.forEach(movie->System.out.println(movie));
	            
               
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }



	}

}
