package com.lumen.prepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PreInsertDemo {

	public static void main(String[] args) {
		
		   String url = "jdbc:mysql://localhost:3306/mysql";
	        String username = "root";
	        String password = "admin@123";

	        boolean result;
	        try {
	            Connection connection =  DriverManager.getConnection(url,username,password);

	            String query = 
	                    "insert into movie values(?,?,?,?)";

	            PreparedStatement prepStatement = connection.prepareStatement(query);
	            prepStatement.setString(1, "titanic");
	            prepStatement.setInt(2, 223);
	            prepStatement.setString(3, "bglr");
	            prepStatement.setInt(4, 2323);


	            result = prepStatement.execute();

	            System.out.println("Table inserted: "+result);


	        } catch (SQLException e) {
	            e.printStackTrace();
	        }


	 

	    }

	 

}


