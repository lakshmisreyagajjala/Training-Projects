package com.lumen.prepared;

public class Movie {

	private  String moviename;
	private int movieid;
	private String city;
	private int price;
	public Movie() {
		super();
	}
	public Movie(String moviename, int movieid, String city, int price) {
		super();
		this.moviename = moviename;
		this.movieid = movieid;
		this.city = city;
		this.price = price;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
	
	
	