package com.lumen.threads;

class Child extends Thread{

	public Child(String name, int priority) {
		super(name);
		this.setPriority(priority);
		System.out.println(this);
		this.start();
	}

	@Override
	public void run() {
		
		String tname = Thread.currentThread().getName();
		for(int i=0;i<5;i++) {
			System.out.println(tname+" "+i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}



public class ExThread {

	public static void main(String[] args) {
		
		Thread child1 = new Child("Puppy",Thread.MAX_PRIORITY);
		Thread child2 = new Child("Kitty",Thread.MIN_PRIORITY);
		Thread child3 = new Child("Piggy",Thread.NORM_PRIORITY);
		
		
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread().getName()+" "+i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		

	}

}
