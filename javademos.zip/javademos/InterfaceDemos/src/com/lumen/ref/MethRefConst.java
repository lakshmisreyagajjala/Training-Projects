package com.lumen.ref;

import java.util.Arrays;
import java.util.List;

public class MethRefConst {

	public static void main(String[] args) {
		
		CourseDetails course = () -> Arrays.asList();
		System.out.println(course);

	}

}




//
//interface CourseDetails{
//	List<String> showCourses();
//}