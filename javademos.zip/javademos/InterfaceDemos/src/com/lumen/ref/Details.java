package com.lumen.ref;

public class Details {
	
	String showName(String name) {
		if(name=="Sreya") {
			return "Hello "+name;
		}
		return "wrong username";
		
	}

}
