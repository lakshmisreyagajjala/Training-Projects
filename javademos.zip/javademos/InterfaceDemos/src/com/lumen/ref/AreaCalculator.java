package com.lumen.ref;

public interface AreaCalculator {
	
	void calcArea(double x, double y);
	

}

