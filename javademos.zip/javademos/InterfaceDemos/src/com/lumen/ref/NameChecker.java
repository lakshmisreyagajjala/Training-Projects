package com.lumen.ref;

public interface NameChecker {
	
	String checkName(String name);

}
