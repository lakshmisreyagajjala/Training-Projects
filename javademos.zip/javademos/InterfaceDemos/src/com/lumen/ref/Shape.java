package com.lumen.ref;

public class Shape {
	
	void rectangleArea(double x, double y) {
		System.out.println("Rect "+(x*y));
	}


}
