package com.lumen.ref;

class Course{
	String courseName;
	void show() {
		System.out.println("Showing courses");
	}
}


//functional interface
interface CourseDetails{
	Course getCourse();
}


public class RefConstDemo {

	public static void main(String[] args) {
		//using lambda to implement this returns a course object
		CourseDetails coursedetails = () -> new Course();
		Course course = courseDetails.getCourse();
		course.show();

	}

}
