package com.lumen.ref;

public class MethodReferenceDemo {
	
	public static void main(String[] args) {
		
		//using lambda
		AreaCalculator areacalculator = (double x, double y)->System.out.println(x*y);
		areacalculator.calcArea(20, 30);
		
		//using non-static
		Shape shape = new Shape();
		AreaCalculator areacalculator1 = shape::rectangleArea;
		areacalculator1.calcArea(20,30);
		
		Details details = new Details(); 
		NameChecker checker = details::showName;
		System.out.println(checker.checkName("Lucky"));
		
		TriArea triarea = triarea::triArea;
		System.out.println(triarea.triArea("Lucky"));
		
		
		
	}

}
