package com.lumen.fun;

public interface Checker {
	
	boolean checkName(String username, String city);

	
}

