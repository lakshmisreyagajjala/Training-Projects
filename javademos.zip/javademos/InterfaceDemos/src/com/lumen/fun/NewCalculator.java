package com.lumen.fun;

public interface NewCalculator {
	
	void calculate(int x, int y);


}
