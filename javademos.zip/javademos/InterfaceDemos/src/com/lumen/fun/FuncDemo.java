package com.lumen.fun;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;

public class FuncDemo {

	public static void main(String[] args) {
		
		Function<String,Integer> fun = (str)->str.length();
		//call apply method
		fun.apply("Lucky");
		
		Function<String,String> fun1 = (str)->str.toUpperCase();
		//call apply method
		System.out.println(fun.apply("Sreya"));
		
		Function<Book,String> fun2 = (book)->book.getTitle();
		//call apply method
		System.out.println(fun2.apply(new Book("a","b",300)));
		
		Function<String,Book> fun3 =(author)->{
			if(author.equals("Kind")) {
				return new Book();
			}
			else
				return null;
			
		   };
		System.out.println(fun3.apply("Kind"));
		
		Function<Integer,List<String>> fun4 = (num)->{
			if(num==2)
				return Arrays.asList("Java","Angular");
			if(num==3)
				return Arrays.asList("Java","Angular","Node");
			else
				return null;
			
		};
		
		Predicate<String> predict = (condition)->{
			if(condition.length()==3) {
				return true;
			}
			else
				return false;
		};
		System.out.println(predict.test("sreya"));
		
		BiPredicate<String,Integer> bipredict = (str,num)->{
			if(str.length()==1) {
				return true;
			}else
				return false;
		};
		System.out.println(bipredict.test("lucky", 535));

	}

}
