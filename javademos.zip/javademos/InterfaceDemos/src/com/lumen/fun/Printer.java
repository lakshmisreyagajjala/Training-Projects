package com.lumen.fun;

public interface Printer {
	
	String print();
	

}
