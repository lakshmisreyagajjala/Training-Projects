package com.lumen.fun;

public class LamMain {

	public static void main(String[] args) {
		
		Checker checker = (username, city)->{
			if(username.equals("Viswa") && city.equals("Nikk")) {
				return true;
			}
			
			return false;
			
			
		};
		System.out.println(checker.checkName("Viswa", "Nikk"));
	

	}

}
