package com.lumen.fun;

public class AnonyDemo {

	public static void main(String[] args) {
		
		Greeter greeter = new GreeterImpl();
		greeter.greetUser("Vishuuu");
		
		Greeter greetOne = new Greeter() {

			@Override
			public void greetUser(String username) {
				System.out.println("Good day "+username);
				
		    }
			
		};
		
		greetOne.greetUser("Nikki");
		
		Greeter greetTwo = new Greeter() {

			@Override
			public void greetUser(String username) {
				System.out.println("Welcome "+username);
				
			}
			
			
		};
		
		greetTwo.greetUser("Bhavi");

	}

}
