package com.lumen.fun;

public class LambdaDemo {
	public static void main(String[] args) {
		
		Greeter greeter = (String username)->{
			System.out.println("Hello "+username);
		};
		
		greeter.greetUser("Lucky");
		
		Greeter greeter1 = username->System.out.println("Welcome "+username);
		greeter1.greetUser("Sree");
	}

}
