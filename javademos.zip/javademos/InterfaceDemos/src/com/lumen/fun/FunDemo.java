package com.lumen.fun;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class FunDemo {

	public static void main(String[] args) {
		
		//implements consumer using lambda
		Consumer<String> con = (str)-> System.out.println(str.toUpperCase());
		//call the method
		con.accept("Sree");	
		
		//do it for Book
		Consumer<Book> book1 = (Book book)-> System.out.println(book.getTitle());
		book1.accept(new Book("sree","lucky",3000));
		
		Supplier<String> supplier =()-> "Hello".toUpperCase();
		String result = supplier.get();
		System.out.println(result);
		
		Supplier<Integer> supplier1 =()-> 35000;
		
		Supplier<String> supplier2 =()-> new Book("a","c",300);
		String result = supplier2.get();
		System.out.println(result);
		
		

	}

}
