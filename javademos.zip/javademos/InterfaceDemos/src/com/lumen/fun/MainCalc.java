package com.lumen.fun;

public class MainCalc {

	public static void main(String[] args) {
         
		NewCalculator addition = (x,y) -> System.out.println(x+y);
		NewCalculator subtraction = (x,y) -> System.out.println(x-y);
		NewCalculator multiplication = (x,y) -> System.out.println(x*y);	
		
		addition.calculate(35,28);
		subtraction.calculate(35,28);
		multiplication.calculate(58,37);
		
		Printer printer = ()->{
			return "Great day";
		};
		System.out.println(printer.print());
		 
		printer = ()->{
		return "Welcome back";
		};
		System.out.println(printer.print());
	
		
}

}
