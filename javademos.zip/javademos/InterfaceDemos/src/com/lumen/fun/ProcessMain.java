package com.lumen.fun;

public class ProcessMain {

	public static void main(String[] args) {
		
		Processor processor = new Processor();
		processor.processData(new Adder(), 10, 30);
		
		//anonymous
		processor.processData(new NewCalculator() {

			@Override
			public void calculate(int x, int y) {
				System.out.println("Sum "+(x+y));
				
			}
			
		},10,50);
		
		//lambda
		processor.processData((int x, int y)->{
			System.out.println(x-y);
		
		}, 80, 30);
		
		processor.processData((int x, int y)->System.out.println(x*y), 40, 60);
		

	}

}

