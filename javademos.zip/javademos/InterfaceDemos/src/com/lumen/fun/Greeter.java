package com.lumen.fun;

public interface Greeter {
	
	void greetUser(String username);

}
