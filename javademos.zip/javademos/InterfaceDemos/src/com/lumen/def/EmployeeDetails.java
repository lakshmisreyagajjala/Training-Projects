package com.lumen.def;

public class EmployeeDetails implements BonusCalculator, AllowanceCalculator{

	@Override
	public void calculate(int amount) {
		System.out.println("Bonus "+(amount*10));
		
	}

	@Override
	public void greet() {
		BonusCalculator.super.greet();
		System.out.println("good morning");
	}

	@Override
	public void policyType() {
		BonusCalculator.super.policyType();
		AllowanceCalculator.super.policyType();
		System.out.println("policy of employee");
	}
	
	

}
