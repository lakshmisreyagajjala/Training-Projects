package com.lumen.def;

public class AnonDemo {

	public static void main(String[] args) {
		
		BonusCalculator calc = new EmployeeDetails();
		BonusCalculator bonus = new BonusCalculator() {

			@Override
			public void calculate(int amount) {
				System.out.println(amount*5);
				
			}
			
		};
		bonus.calculate(100);

	}

}
