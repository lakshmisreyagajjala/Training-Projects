package com.lumen.def;

public class DefMain {

	public static void main(String[] args) {
		
		BonusCalculator bonuscalculator = new EmployeeDetails();
		bonuscalculator.calculate(3000);
		bonuscalculator.greet();
        bonuscalculator.policyType();
        BonusCalculator.call();
	}

}

