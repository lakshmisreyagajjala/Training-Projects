package com.lumen.extend;

public class SciMain {

	public static void main(String[] args) {

		Scientific scientific = new SciCalculator();
		scientific.add(35, 28);
		scientific.difference(58, 37);
		
		SciCalculator calc = (SciCalculator) scientific;
		calc.square(3);
		calc.cube(30);
		calc.difference(10, 2);
		
		
}

}
