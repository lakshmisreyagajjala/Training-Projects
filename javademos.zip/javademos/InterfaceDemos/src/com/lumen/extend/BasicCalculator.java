package com.lumen.extend;

public class BasicCalculator implements Calculator {

	@Override
	public void add(int x, int y) {
		System.out.println("Add "+(x+y));
		
	}

	@Override
	public void product(int x, int y) {
		System.out.println("Multiply "+(x*y));
		
	}
	

}
