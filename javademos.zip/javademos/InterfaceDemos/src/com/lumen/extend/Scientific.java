package com.lumen.extend;

public interface Scientific extends Calculator {

	void square(int x);
	void cube(int z);
}
