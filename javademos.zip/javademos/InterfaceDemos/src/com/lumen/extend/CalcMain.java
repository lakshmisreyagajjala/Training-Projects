package com.lumen.extend;

public class CalcMain {

	public static void main(String[] args) {
		 
		Calculator calc = new BasicCalculator();
		calc.add(35,28);
		calc.product(58,37);
		

	}

}
