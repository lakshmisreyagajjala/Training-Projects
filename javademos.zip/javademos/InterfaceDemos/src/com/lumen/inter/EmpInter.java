package com.lumen.inter;

public abstract class EmpInter implements Insurance,Entertainment {
	
		String name;
		int empId;
		double salary;
		public EmpInter(String name, int empId, double salary) {
			super();
			this.name = name;
			this.empId = empId;
			this.salary = salary;
		}
		
		void printDetails() {
			System.out.println("name:"+name);
			System.out.println("empId"+empId);
			System.out.println("salary"+salary);
			
		}
		
		abstract void showCourses();
		

		

}





