package com.lumen.inter;

public interface InterOne {
	
	void greetUser();

}
