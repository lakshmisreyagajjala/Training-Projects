package com.lumen.inter;

public class InterMain {

	public static void main(String[] args) {
		
		InterOne interone = new InterOneImpl();
		interone.greetUser();
		

	}

}
