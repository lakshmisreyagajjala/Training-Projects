package com.lumen.inter;

public interface Insurance {
	
	void healthinsurance();
	void vehicleinsurance();
	

}
