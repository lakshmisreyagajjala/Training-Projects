package com.lumen.inter;

public class MainInter {

	public static void main(String[] args) {
		
		
		Developer developer = new Developer("Sreya",535,11111);
		developer.healthinsurance();
		developer.vehicleinsurance();
		developer.indoor();
		developer.outdoor();
		developer.showCourses();
		developer.showTrips();
		
		EmpInter manager = new Manager("Bhavya",531,122222);
		manager.printDetails();
		manager.showCourses();
		manager.showTrips();
		
		Insurance insurance = manager;
		insurance.healthinsurance();
		insurance.vehicleinsurance();
		
		Entertainment entertainment = manager;
		entertainment.showTrips();
		
		Manager manage = (Manager) manager;
		manage.printDetails();

	}

}
