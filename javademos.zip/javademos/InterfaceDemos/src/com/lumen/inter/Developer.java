package com.lumen.inter;

public class Developer extends EmpInter implements Entertainment, Gamer {

	public Developer(String name, int empId, double salary) {
		super(name, empId, salary);
	}

	@Override
	public void indoor() {
        System.out.println("Indoor game");
	}

	@Override
	public void outdoor() {
        System.out.println("Outdoor game");
	}

	@Override
	public void showTrips() {
        System.out.println("Trips");
	}

	@Override
	void showCourses() {
        System.out.println("courses of manager");
	}

	@Override
	public void healthinsurance() {
		System.out.println("details of health");
	}

	@Override
	public void vehicleinsurance() {
		System.out.println("details of vehicle");
	}

}
