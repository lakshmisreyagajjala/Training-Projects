package com.lumen.inter;

public class TriArea {
	
	void triArea(double x, double y) {
		System.out.println("Triangle "+0.5*x*y);
	}
	

}
