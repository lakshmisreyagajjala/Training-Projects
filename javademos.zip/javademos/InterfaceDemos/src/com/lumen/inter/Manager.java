package com.lumen.inter;

public class Manager extends EmpInter implements Entertainment {

	public Manager(String name, int empId, double salary) {
		super(name, empId, salary);
	}

	@Override
	public void showTrips() {
		System.out.println("Show trips");

	}

	@Override
	void showCourses() {
		System.out.println("manager courses");

	}

	@Override
	public void healthinsurance() {
		System.out.println("deatails of health insurance");
		
	}

	@Override
	public void vehicleinsurance() {
		System.out.println("details of vehicle insurance");
		
	}

}

