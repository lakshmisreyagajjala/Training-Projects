package com.lumen.inter;

public interface Entertainment {

	void showTrips();
}
