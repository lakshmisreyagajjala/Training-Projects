package com.lumen.inter;

public interface Gamer {

	void indoor();
	void outdoor();
	
}
