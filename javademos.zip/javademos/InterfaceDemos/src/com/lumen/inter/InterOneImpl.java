package com.lumen.inter;

public class InterOneImpl implements InterOne {

	@Override
	public void greetUser() {
		System.out.println("Great day");
		
	}

}

