package com.oops.basics;

enum VehicleDetails{
	
	HONDA("Honda",90000),
	AUDI("Audi",1000000),
	MAHINDRA("Thar",800000),
	BMW("BMW 300",1300000);
	
	private String model;
	private double price;
	private VehicleDetails(String model, double price) {
		this.model = model;
		this.price = price;
	}
	public String getModel() {
		return model;
	}
	public double getPrice() {
		return price;
	}
}
public class EnumConstrDemo {

	public static void main(String[] args) {
		
         VehicleDetails details = VehicleDetails.BMW;
         System.out.println("Model "+details.getModel());
         System.out.println("Price "+details.getPrice());
         
         String modelofHonda = VehicleDetails.HONDA.getModel();
         double priceofHond = VehicleDetails.HONDA.getPrice();
         
         
	}

}

