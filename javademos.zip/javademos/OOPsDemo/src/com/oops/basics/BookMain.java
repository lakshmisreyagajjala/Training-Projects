package com.oops.basics;

public class BookMain {

	public static void main(String[] args) {
		
		Book book = new Book();
		Book book1 = new Book();
		book.bookName="Alane";
		book.bookAuthor="Venkatesh";
		book.bookPrice="5000";
		book.getDiscountedPrice(5000);
		book.getDiscountedPrice(3000);
		book.printDetails();
		
		System.out.println("");

	}

}
