package com.oops.basics;

import java.util.Scanner;

enum Seasons{
	 
	 SUMMER,WINTER,RAINY,AUTUMN;
	 
	
}

public class EnumSwitch {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		String choice = scanner.next().toUpperCase();
	    Seasons season = Seasons.valueOf(choice);
	
		switch(season) {
		case SUMMER:{
			System.out.println("summer is very hot, eat icecreams");
			break;
		}
		case RAINY:{
			System.out.println("drink tea in rainy days");
			break;
		}
		case WINTER:{
			System.out.println("drink more soups to keep yourself warm");
			break;
		}
		case AUTUMN:{
			System.out.println("go out and enjoy");
			break;
		}
		default:
			System.out.println("Invalid");
		    break;
		}
		scanner.close();
	}

}
