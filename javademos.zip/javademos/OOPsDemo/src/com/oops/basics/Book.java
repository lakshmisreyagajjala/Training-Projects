package com.oops.basics;

public class Book {

		
		String title;
		String author;
		double price;
		
		void printDetails() {
			System.out.println("Title"+title);
			System.out.println("Author"+author);
			System.out.println("Price"+price);
		}
		
		String greet(String msg) {
			return msg;
		}

	}


