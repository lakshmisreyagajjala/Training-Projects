package com.oops.basics;

public class EmpMain {
	
	public static void main(String[] args) {
		Employee employee = new Employee("Sita",12,2000.0);
//		System.out.println(employee.empName);
//		System.out.println(employee.empId);
//		employee.empName="Sreya";
//		employee.empId=13;
//		employee.salary=3000;
//		System.out.println("Employee name"+employee.empName);
//		System.out.println("Employee empId"+employee.empId);
//		System.out.println("Employee salary"+employee.salary);
		
		employee.printDetails();
		String result = employee.greet("Great Day\t");
		System.out.println(result);
		
		//create the 2nd employee object
		Employee employee1 = new Employee("sree",10,1000);
		employee1.empName="Lucky";
		employee1.empId=11;
		employee1.salary=4000;
		employee.printDetails();
		System.out.println(employee1.greet("Welcome"));
		
//		System.out.println("Employee1 name"+employee.empName);
//		System.out.println("Employee1 empId"+employee.empId);
//		System.out.println("Employee1 salary"+employee.salary);
		
//		Employee employee2 = employee;
//		System.out.println("Employee2 name"+employee2.empName);
//		employee2.empName ="Raj";
//		System.out.println("Employee2 name"+employee2.empName);
//		System.out.println("Employee name"+employee.empName);
//		
//		//make employee null
//		employee = null;
//		System.out.println("Employee2 name"+employee2.empName);
//		System.out.println("Employee name"+employee.empName);
		
		}


}
