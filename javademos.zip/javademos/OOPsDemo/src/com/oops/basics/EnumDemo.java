package com.oops.basics;

public class EnumDemo {
	
	enum Weekdays{
		MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY
	}
	
	public static void main(String[] args) {
		Weekdays weekday   = Weekdays.FRIDAY;
		System.out.println(weekday.name());
		System.out.println(weekday.ordinal());
		
		Weekdays[] weekdayArr = Weekdays.values();
		
		for(Weekdays weekdays : weekdayArr) {
			System.out.println(weekdays.name());
		}
		System.out.println("Convert string to enum constant");
		weekday = Weekdays.valueOf("MONDAY");
		System.out.println(weekday);
		
	}

}
