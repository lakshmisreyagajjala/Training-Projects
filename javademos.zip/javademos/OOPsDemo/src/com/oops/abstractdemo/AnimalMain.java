package com.oops.abstractdemo;

public class AnimalMain {

	public static void main(String[] args) {
		
		Animal animal = new Dog();
		animal.makeSound();
		
		Dog dog = (Dog)animal;
		dog.play();
		
		animal = new Cat();
		animal.makeSound();
		Cat cat = (Cat)animal;
		cat.play();

}

}
