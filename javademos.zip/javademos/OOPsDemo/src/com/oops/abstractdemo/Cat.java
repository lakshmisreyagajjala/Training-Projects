package com.oops.abstractdemo;

public class Cat extends Animal {

	@Override
	void makeSound() {
		System.out.println("Meow");
		
	}
	void play() {
		System.out.println("Scratch sound");
	}

}
