package com.oops.abstractdemo;

public abstract class Branch2 extends Bank {

	@Override
	void carLoan() {
		System.out.println("Car loan in branch2");
		
	}

	@Override
	void houseLoan() {
		System.out.println("House loan in branch2");
		
	}
	
	void loanType() {
		System.out.println("Easy EMI loans in branch2");
	}

	
	

}
