package com.oops.abstractdemo;

public class AbsMain {

	public static void main(String[] args) {
		
		Bank bank = new Branch1();
		bank.carLoan();
		bank.houseLoan();
		bank.eduLoan();
		bank.admin();
		
		Branch1 branch1 = (Branch1)bank;
		branch1.staffDetails();
		
		bank = new Subbranch();
		bank.carLoan();
		bank.houseLoan();
		bank.eduLoan();
		bank.admin();
		
		Subbranch subbranch = (Subbranch)bank;
		subbranch.loanType();
		subbranch.subPay();
		
		
}

}
