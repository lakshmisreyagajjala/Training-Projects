package com.oops.abstractdemo;

public class Dog extends Animal{

	@Override
	void makeSound() {
		System.out.println("Barking");
	}
	void play() {
		System.out.println("Fetch ball");
	}
	

}
