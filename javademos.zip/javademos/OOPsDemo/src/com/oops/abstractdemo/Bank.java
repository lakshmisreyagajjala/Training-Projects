package com.oops.abstractdemo;

public abstract class Bank {
	
	abstract void carLoan();
	abstract void houseLoan();
	abstract void eduLoan();
	
	void admin() {
		System.out.println("Admin details in bank");
	}
	

}
