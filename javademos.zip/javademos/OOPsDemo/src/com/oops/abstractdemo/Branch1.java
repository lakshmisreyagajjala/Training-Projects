package com.oops.abstractdemo;

public class Branch1 extends Bank {

	@Override
	void admin() {
		System.out.println("In branch1");
	}

	@Override
	void carLoan() {
		System.out.println("Car loan in branch1");

	}

	@Override
	void houseLoan() {
		System.out.println("House loan in branch1");

	}

	@Override
	void eduLoan() {
		System.out.println("Education loan in branch1");

	}
	
	void staffDetails() {
		System.out.println("Staff in branch1");
	}

}
