package com.oops.abstractdemo;

public class Subbranch extends Branch2{

	@Override
	void eduLoan() {
		System.out.println("Education loan in subbranch");
		super.carLoan();
	}
	
	void subPay() {
		System.out.println("payment in subbranch");
	}
	
	

}
