package com.oops.abstractdemo;

public abstract class Animal {
	
     abstract void makeSound();
     
}
