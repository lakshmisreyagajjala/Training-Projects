package com.oops.inher;

public class InEmployee {
	String name;
	int employeeId;
	
	public InEmployee(String name, int employeeId) {
		super();
		this.name = name;
		this.employeeId = employeeId;
	}
	void print() {
		System.out.println();
		System.out.println();
	}

}
