package com.oops.inher;

public class Mobile extends Electronics {

	String cameraType;
	public Mobile(String cameraType, String brand, double price,String model) {
		super(model, brand, price);
		this.cameraType="icon";
		
	}
	void showCameraType() {
		System.out.println("cameraType"+cameraType);
	}
	
	

}
