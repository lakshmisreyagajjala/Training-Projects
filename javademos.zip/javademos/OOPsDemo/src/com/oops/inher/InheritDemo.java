package com.oops.inher;

public class InheritDemo {
	
	public static void name() {
		
		InManager inmanager = new InManager();
		InheritDemo inheritdemo = new InheritDemo();
		
		employee.print();
		
		manager.printBonus(10000);
		
		manager.print();
		
	}

}
