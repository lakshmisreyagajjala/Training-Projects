package com.oops.inher;

public class ElecMain {

	public static void main(String[] args) {
		Electronic electronic = new Electronic();
		
	}
}
