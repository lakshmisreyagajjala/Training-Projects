package com.oops.override;

public class Shaper {
	
	void area(int x,int y) {
		System.out.println("Calculating area");
	}
	void greet() {
		System.out.println("Hello");
	}

}
