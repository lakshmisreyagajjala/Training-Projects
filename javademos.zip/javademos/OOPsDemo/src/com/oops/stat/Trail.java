package com.oops.stat;

public class Trail {
	
	static int x;
	static int y=10;
	
	static {
		System.out.println("In static block");
		x=200;
	}
	public static void main(String[] args) {
		System.out.println("In main");
	}
	static {
		System.out.println("static method");
	}
	static void getMessage() {
		System.out.println("method");
		System.out.println("Sum"+(x+y));
	}

}
