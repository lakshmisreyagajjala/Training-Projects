/**
 * GreeterServiceImplSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.greet.ws;

public class GreeterServiceImplSoapBindingImpl implements com.greet.ws.GreeterServiceImpl{
    public java.lang.String welcome(java.lang.String name) throws java.rmi.RemoteException {
        return "Welcome "+name;
    }

}
