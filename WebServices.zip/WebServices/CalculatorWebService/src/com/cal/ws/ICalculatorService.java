package com.cal.ws;

import javax.jws.WebMethod;

@WebService
public interface ICalculatorService {
	
    @WebMethod
	public int add(@WebParam int x, int y);

}
