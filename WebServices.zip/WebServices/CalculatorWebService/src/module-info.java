/**
 * 
 */
/**
 * 
 */
module CalculatorWebService {
}