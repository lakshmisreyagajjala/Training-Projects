package com.greet.ws;

import javax.jws.WebService;

//specify the endpoint interface
@WebService
public class GreetServiceImpl implements IGreetService{
	
	public String greet(String name) {
		return "Great Day "+name;
	}

}

