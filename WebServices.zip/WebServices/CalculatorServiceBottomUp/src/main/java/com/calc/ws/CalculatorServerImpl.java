package com.calc.ws;

import javax.jws.WebService;

@WebService(endpointInterface="ICalculator")
public class CalculatorServerImpl implements ICalculator {

	@Override
	public double add(int x, int y) {
		return x+y;
	}

}

