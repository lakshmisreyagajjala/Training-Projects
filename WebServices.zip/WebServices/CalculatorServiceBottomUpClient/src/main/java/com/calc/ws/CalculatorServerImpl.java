/**
 * CalculatorServerImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.calc.ws;

public interface CalculatorServerImpl extends java.rmi.Remote {
    public double add(int x, int y) throws java.rmi.RemoteException;
}
