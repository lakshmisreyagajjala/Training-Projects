package com.calc.ws;

public class CalculatorServerImplProxy implements com.calc.ws.CalculatorServerImpl {
  private String _endpoint = null;
  private com.calc.ws.CalculatorServerImpl calculatorServerImpl = null;
  
  public CalculatorServerImplProxy() {
    _initCalculatorServerImplProxy();
  }
  
  public CalculatorServerImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initCalculatorServerImplProxy();
  }
  
  private void _initCalculatorServerImplProxy() {
    try {
      calculatorServerImpl = (new com.calc.ws.CalculatorServerImplServiceLocator()).getCalculatorServerImpl();
      if (calculatorServerImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)calculatorServerImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)calculatorServerImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (calculatorServerImpl != null)
      ((javax.xml.rpc.Stub)calculatorServerImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.calc.ws.CalculatorServerImpl getCalculatorServerImpl() {
    if (calculatorServerImpl == null)
      _initCalculatorServerImplProxy();
    return calculatorServerImpl;
  }
  
  public double add(int x, int y) throws java.rmi.RemoteException{
    if (calculatorServerImpl == null)
      _initCalculatorServerImplProxy();
    return calculatorServerImpl.add(x, y);
  }
  
  
}