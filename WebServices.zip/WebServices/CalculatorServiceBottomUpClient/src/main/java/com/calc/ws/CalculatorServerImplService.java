/**
 * CalculatorServerImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.calc.ws;

public interface CalculatorServerImplService extends javax.xml.rpc.Service {
    public java.lang.String getCalculatorServerImplAddress();

    public com.calc.ws.CalculatorServerImpl getCalculatorServerImpl() throws javax.xml.rpc.ServiceException;

    public com.calc.ws.CalculatorServerImpl getCalculatorServerImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
