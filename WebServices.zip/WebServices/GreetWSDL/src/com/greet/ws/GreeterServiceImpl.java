package com.greet.ws;

import javax.jws.WebService;

@WebService(endpointInterface="IGreeterService")
public class GreeterServiceImpl implements IGreeterService {

	@Override
	public String welcome(String name) {
		return "good morning";
	}
		

}
