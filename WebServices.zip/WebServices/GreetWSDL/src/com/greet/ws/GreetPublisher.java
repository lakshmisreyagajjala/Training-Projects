package com.greet.ws;

import javax.xml.ws.Endpoint;

public class GreetPublisher {

	public static void main(String[] args) {
		
		IGreeterService greetService = new GreeterServiceImpl();
		Endpoint.publish("http://localhost:8089/greeterService", greetService);
		System.out.println("Service published");

	}

}

