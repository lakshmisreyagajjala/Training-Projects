package com.ctl.it.qa.sample.tests;

import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.ctl.it.qa.staf.Environment;
import com.ctl.it.qa.staf.HtmlReport;
import com.ctl.it.qa.staf.STAFEnvironment;
import com.ctl.it.qa.staf.Steps;
import com.ctl.it.qa.staf.TestEnvironment;

import io.cucumber.junit.CucumberOptions;



@TestEnvironment(Environment.TEST1) // Test Environment on which execution is to happen is provided
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/", tags =  "@Sample" )
public class CukesTest {

	@BeforeClass
	public static void setEnvironment() {
		STAFEnvironment.registerEnvironment(CukesTest.class);
		Steps.initialize("sample.xml");// Data input file name (present in SampleTools/src/test/resources) is provided
	}

	@AfterClass
	public static void clearEnvironment() {
		HtmlReport.generate();// To generate customized Html report
	}

}