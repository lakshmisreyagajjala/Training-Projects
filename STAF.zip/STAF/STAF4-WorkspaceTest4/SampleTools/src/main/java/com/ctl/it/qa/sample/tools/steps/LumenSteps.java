package com.ctl.it.qa.sample.tools.steps;

import com.ctl.it.qa.staf.Steps;

@SuppressWarnings("serial")
public abstract class LumenSteps extends Steps {
	
}
