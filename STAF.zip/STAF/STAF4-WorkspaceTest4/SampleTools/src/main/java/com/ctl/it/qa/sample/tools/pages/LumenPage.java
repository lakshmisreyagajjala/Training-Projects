package com.ctl.it.qa.sample.tools.pages;

import com.ctl.it.qa.staf.Page;

public abstract class LumenPage extends Page {


}
