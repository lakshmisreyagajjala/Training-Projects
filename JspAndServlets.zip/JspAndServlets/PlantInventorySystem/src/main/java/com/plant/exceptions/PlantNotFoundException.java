package com.plant.exceptions;

public class PlantNotFoundException extends Exception{

	public PlantNotFoundException() {
		super();
	}

	public PlantNotFoundException(String message) {
		super(message);
	}
	
	

}

