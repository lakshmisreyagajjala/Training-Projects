package com.bookapp.dao;

import java.util.List;
import java.util.Set;

import com.lumen.exception.BookNotFoundException;
import com.lumen.model.Book;

public interface IBookDao {
	
	    //crud operation
		void addBook(Book book);
		void updateBook(int bookId,double price);
		void deleteBook(int bookId);
		
		List<Book> getAll();
		List<Book> getByAuthorContains(String author) throws BookNotFoundException;
		List<Book> getByCategory(String category) throws BookNotFoundException;
		Set<Book> getByPriceLessThan(double price) throws BookNotFoundException;
		Set<Book> getByAuthorContainsAndCategory(String author, String category) throws BookNotFoundException;
		List<Book> getId(int bookId) throws BookNotFoundException;
		
		

}
