package com.doctorapp.exceptions;

public class DoctorNotFoundException extends RuntimeException {

	public DoctorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DoctorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
