package com.employeeapp.model;

import java.util.Arrays;

public class Employee {
	
	private String name;
	private Integer employeeId;
	private String[] hobbies;
	private String language;
	private String city;
	private double salary;
	
	public Employee() {
		super();
	}
	public Employee(String name, Integer employeeId, String[] hobbies, String language, String city, double salary) {
		super();
		this.name = name;
		this.employeeId = employeeId;
		this.hobbies = hobbies;
		this.language = language;
		this.city = city;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String[] getHobbies() {
		return hobbies;
	}
	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", employeeId=" + employeeId + ", hobbies=" + Arrays.toString(hobbies)
				+ ", language=" + language + ", city=" + city + ", salary=" + salary + "]";
	}
	
	

}
