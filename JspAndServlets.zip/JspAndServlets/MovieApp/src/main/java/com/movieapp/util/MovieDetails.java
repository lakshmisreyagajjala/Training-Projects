package com.movieapp.util;

import java.util.Arrays;
import java.util.List;

public class MovieDetails {
	
	public List<String> showMovies(String language) {
		
	
		List<String> movies = null;

		 

        if(language.equals("english")) {



            movies = Arrays.asList("Titanic ", "OpenHeimer ", "Jumanji ", "The Lost City ");



        } else if(language.equals("telugu")) {



            movies = Arrays.asList("Bahubali 1 ", "Bahubali 2 ", "RRR ", "KGF 1 ", "KGF 2 ");



        } else if(language.equals("hindi")) {



            movies = Arrays.asList("Koyi Mil Gaya ", "Krish ", "Dilse ", "Vivah ");



        } else if(language.equals("tamil")) {



            movies = Arrays.asList("Dia ", "Love Moctile ", "Karnan ", "June ");



        } else if(language.equals("kanada")) {



            movies = Arrays.asList("KGF 1 ", "KGF 2 ", "Kantara ", "Bell Bottom ", "VR ");



        }



        return movies;



    }
	

}

