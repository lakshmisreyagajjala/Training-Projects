package com.bookapp.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.bookapp.model.Book;
import com.lumen.service.BookServiceImpl;
import com.lumen.service.IBookService;


/**
 * Servlet implementation class AddBookServlet
 */
@WebServlet("/addBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String category = request.getParameter("category");
		String author = request.getParameter("author");
		int bookId = Integer.parseInt(request.getParameter("bookId"));
		int price = Integer.parseInt(request.getParameter("price"));
		com.bookapp.model.Book books = new com.bookapp.model.Book();
		books.setTitle(title);
		books.setCategory(category);
		books.setBookId(bookId);
		books.setPrice((double)price);
		books.setAuthor(author);
		request.setAttribute("books",books);
		bookService.addBook(books);
		List<String> bookList = (List) bookService.getAll();
		request.setAttribute("message", "book added sucessfully");
		request.setAttribute("booklist", bookList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("final.jsp");
		dispatcher.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


