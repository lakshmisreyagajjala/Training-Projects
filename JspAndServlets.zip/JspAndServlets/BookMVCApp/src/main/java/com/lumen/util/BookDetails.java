package com.lumen.util;

import java.util.ArrayList;

import com.bookapp.model.Book;
import com.bookapp.dao.*;
import java.util.Arrays;
import java.util.List;


public class BookDetails {
	
	
	public static void addBooks(Book book) {
//		bookList.add(book);
		IBookDao bookDao = new BookDaoImpl();
		bookDao.addBook(book);
	}
	
	
	public static List<Book> showBooks() {
		IBookDao bookDao = new BookDaoImpl();
		List<Book> bookList = bookDao.findAll();
		return bookList;
		
	}



}

